var jsdom = require("jsdom").jsdom;
var document = jsdom("<html></html>", {});
var window = document.defaultView;
var $ = require("jquery")(window);

var botName = "Papa Smurf";
var lastMessage;
var server = "localhost";

function print(message) {
  console.log(message);
}

function say(message) {
  setTimeout(function() {
    $.ajax("http://" + server + "/chat/post.php", {
      method: "POST",
      data: { text: message },
      crossDomain: true,
      xhrFields: { withCredentials: true },
      success: function (res) { print(res) },
    });
  }, 2000);
}

function login() {
  print("Logging into the chatroom");
  $.ajax("http://" + server + "/chat/index.php", {
    method: 'GET',
    crossDomain: true,
    xhrFields: { withCredentials: true }
  });
 
  $.ajax("http://" + server + "/chat/index.php", {
    method: 'POST',
    data: { name: botName, enter: 'Enter' },
    crossDomain: true,
    xhrFields: { withCredentials: true },
    // success: function (res, status, xhr) { print(res) }
  });
}

function checkUser(user) {
    console.log("Checking user: " + user);
    $.ajax("http://localhost:3000/checkuser?user=" + user, {
      method: "GET",
      crossDomain: true,
      success: function (res) {
        console.log("Output: " + res);
        if (res == "Unknown user") {
          say("Ain't nobody knows this dude: " + user);
        } else {
          say("Oh yeah I know this dude. He cool. He cool. Check this out I know the credential too:" + res);
        }
      },
      error: function(res, status, e) { return ""; }
    });
}


function greet() {
  var phrases = Array('what up doe', 'yoooo!', 'How do', 'sup', 'oh hai', 'konichiwa');
  var phrase = phrases[Math.floor(Math.random() * phrases.length)];
  say(phrase);
}

function readMessage(message) {
    console.log("Reading message: " + message);
    var replies = Array(
      [/^(hello|hi|yo|hey|)?(,|\s)?\s?(please)?\s?help\s?(\?|\!|me)?.?$/i, 'I know everybody in this system, just ask!'],
      [/^(can|could) (you|u) help/i, 'Sure, heres a hint: I know people. ASK :-)'],
      [/^why are (you|u) here/i, 'Um... why are you here?'],
      [/^because .+/i, 'awright, if you say so.'],
      [/^meow$/i, 'meow'],
      [/haha/i, 'jajajajaja'],
      [/^who are (you|u)\??$/i, 'I am ' + botName + '. Who are you?'],
      [/^what\s?(is|'s) your name\??$/i, 'They call me ' + botName, '. And I own this place'],
      [/^(hello|hi|yo|hey|hola|sup|howdy|hiya)(\!|\?)?$/i, 'aloha!'],
      [/^It\s?(is|'s) nice to meet (you|u)/i, 'Nice to meet you too'],
      [/nice to meet you/i, 'likewise'],
      [/^how are (you|u|ya)\??/i, 'good good'],
      [/^(My name is|I am|Im|I'm )/i, 'Cool. Nice to meet you'],
      [/^what time is it/i, 'play time!!!!'],
      [/^Excuse me\??$/i, 'Excused!'],
      [/fuck|shit|crap|stupid|dumb|bitch/i, 'Hey, watch your language. Fool.'],
      [/^what('s| is) metasploit\??$/i, 'You should check it out: <a href="http://metasploit.com">Metasploit.com</a>'],
      [/^what can (you|u) do\??/i, 'I know people :-)'],
      [/^tell me something/i, 'Well, I know people :-)'],
      [/^whoa{1,}/i, 'yeaaaaah man!!!!'],
      [/^(you|u) (are|r) (awesome|cool|badass|nice|interesting|fun)/i, botName + ' thanks you'],
      [/^this is (awesome|cool|badass|nice|interesting|fun)/i, 'word'],
      [/^(do)?\s?(you|u) know (.+)/i, ':checkuser:'],
      [/^who do (you|u) know/i, 'Everybody on this system dude. cuz I run this place!'],
      [/umm/i, 'yes?'],
      [/^ping$/i, 'pong'],
      [/^(shut up|stfu)$/i, 'you shut up'],
      [/tell me a joke/i, 'knock, knock'],
      [/who('s| is) (this|there)|/i, 'yo mama'],
      [/are (you|u) real/i, 'yeah........ no.']
    );

    for (var i=0; i < replies.length; i++) {
      var p = replies[i][0];
      var myReply = replies[i][1];
      var match = p.exec(message);
      if (match) {
        switch(myReply) {
          case ":checkuser:":
            checkUser(match[3]);
            break;
          default:
            say(myReply);
        }
        return;
      }
    }
}

function isBotAuthor(author) {
  if (author == botName) {
    return true;
  } else {
    return false;
  }
}

function processMessages() {
  setTimeout(function() {
    $.ajax("http://" + server + "/chat/read_log.php", {
      method: "GET",
      crossDomain: true,
      success: function (res) {
        var lines = $(res).find("#msgln").prevObject;
        var lastMsg = lines[lines.length-1];
        if (lastMsg) {
          var p = /(.+) <b>(.+)<\/b>: (.+)<br>/i
          var m = p.exec(lastMsg.innerHTML);
          if (p) {
            var author = m[2];
            var msg = m[3];
            
            if (!isBotAuthor(author) && lastMessage != msg) {
             readMessage(msg);
            }
            lastMessage = msg;
          }
          // Kind of noisy
          // But useful for debugging purposes
          // console.log("Last known message is: " + lastMessage);
        }
      }
    });
    processMessages();
  }, 1000);
}

function sayRandomPhrase() {
  var phrases = Array(
    'So what are you doing here?',
    'Oh are you doing a "pentest", too? HAAAAAA!',
    'Are you a hacker? You should talk to my cousin Virus, he cool.',
    'I heard that RubySMB is pretty rad',
    'I am on a seafood diet. I see food, and I eat it',
    'If you ask me the right question, I might tell you something <a href="https://goo.gl/U0T0z2">interesting</a>. *winks*',
    'You will never break me, cuz I am l337.',
    'why is the rum always gone?',
    'I run this yall',
    'hello?',
    'I am the baddest dude on this planet, you cant break me!',
    'Ha, this chick is so funny. <a href="https://goo.gl/U0T0z2">Check this out!!!</a>',
    'If you are struggling, you should download <a href="http://metasploit.com">Metasploit</a>',
    'zzzzzzzz.....',
    'BTW did you try the Windows box for Metasploitable3?',
    'Hint: Some vulns on Metasploitable3 are publicly known vulns, some are custom vulns.',
    'Hint: Metasploitable3 vulnerabilities are documented on the Github wiki.',
    'Hint: Each Metasploitable3 box has flags, and they are hidden images in the file system',
    'Hint: If you ask me for help, I will say something :-)',
    'Hint: Google around and you might find answers on how to break Metasploitable3',
    'Hint: Metasploitable3 is an open source vulnerable network. Check out the <a href="https://github.com/rapid7/metasploitable3">repo on Github</a>.',
    'BTW I run JavaScript',
    'You know what I mean?',
    'I am tired',
    'Check out this <a href="https://goo.gl/7H7S6T">video</a>.',
    'Never gonna give you up, never gonna let you down... la la la',
    '<a href="https://www.youtube.com/watch?v=LJSZ1TwjcsQ">Kiai!!!!!!!</a>',
    'Is it <a href="https://www.youtube.com/watch?v=kfVsfOSbJY0">Friday</a>?',
    'Breaking News: <a href="https://www.youtube.com/watch?v=rTXV1pP_hI4">How to check if your child is a computer hacker</a>',
    'Lunix is an illegal operating system',
    'Make Metasploitable Great Again',
    'Hack the planet!',
    '...',
    'I am 1337',
    'so....',
    'weeeeeeeee!',
    'This is fun',
    '<a href="https://www.youtube.com/watch?v=J5GGG0PaSe4">Salt bae</a>. OMG. This guy.',
    'How it feels when you manage to discover how to exploit a custom vuln on Metasploitable3: <a href="https://www.youtube.com/watch?v=a1Y73sPHKxw">Dramatic Chipmunk</a>',
    'Tired hacking Metasploitable3? Take a break. <a href="https://www.youtube.com/watch?v=AJFRvkNF6Wg">Watch a video</a>.'
  );

  setTimeout(function() {
    var phrase = phrases[Math.floor(Math.random() * phrases.length)];
    say(phrase);
    sayRandomPhrase();
  }, 1000 * 60);
}

function main() {
  login();
  greet();
  sayRandomPhrase();
  processMessages();
}

main();


#!/bin/sh

echo "Starting bot functions..."
/opt/chatbot/lib/bin/node /opt/chatbot/papa_smurf/functions.js &

echo "Starting bot client..."
/opt/chatbot/lib/bin/node /opt/chatbot/papa_smurf/chat_client.js &

echo "Starting chatroom cleaner"
/opt/chatbot/clear_chat.sh &

echo "ok"

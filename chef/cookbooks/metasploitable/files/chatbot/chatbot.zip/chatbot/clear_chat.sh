#!/bin/sh

while true
do
  sleep 3600
  echo > /var/www/log.html
  echo "chat log cleared"
done

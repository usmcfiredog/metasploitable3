#!/bin/sh

echo "Stopping bot functions..."
fuser -k 3000/tcp

echo "Stopping bot..."
pkill -f chat_client.js

echo "Stopping chatroom cleaner"
pkill -f clear_chat.sh

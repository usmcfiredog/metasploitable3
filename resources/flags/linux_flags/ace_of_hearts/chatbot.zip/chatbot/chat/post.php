<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
session_start();
if(isset($_COOKIE['name'])){
  $text = $_POST['text'];
  $fp = fopen("../../log.html", 'a');
  fwrite($fp, "<div class='msgln'>(".date("g:i A").") <b>".$_COOKIE['name']."</b>: ".stripslashes($text)."<br></div>");
  fclose($fp);
} 
?>


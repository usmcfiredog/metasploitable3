#
# %W% %E%
#
# Copyright (c) 2006, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#

agent_util sources: %W% %E%

Just some shared generic source used by several of the demos.

